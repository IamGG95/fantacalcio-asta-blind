
# Fantacalcio - Asta al buio (Server + Client)

Prototipo funzionante per aste al buio del fantacalcio.
- **Server**: Node.js + Express + Socket.IO (porta 3001)
- **Client**: Vite + React (porta 5173)
- Offerte al buio nascoste fino al termine del countdown
- Admin = primo giocatore che entra
- Countdown modificabile dall'admin

## Avvio locale

```bash
# Server
cd server
npm install
npm start
# in un altro terminale
cd ../client
npm install
cp .env.example .env   # opzionale, modifica VITE_SOCKET_URL se il server non è su localhost:3001
npm run dev
```

Apri http://localhost:5173 e fai join con più tab/device.

## Deploy

### Backend su Render (consigliato)
1. Crea un nuovo servizio **Web Service** dalla tua repo.
2. Root directory: `server`
3. Build command: `npm install`
4. Start command: `node server.js`
5. PORT: `3001` (Render imposta automaticamente, ma è definita anche nel `render.yaml`)

> Alternativa: usa **Blueprint** puntando a questo repo con `render.yaml` nella root.

### Frontend su Vercel
1. Importa la cartella `client` come progetto Vercel.
2. Imposta variabile d'ambiente `VITE_SOCKET_URL` con l'URL HTTPS del server Render (es. `https://tuo-server.onrender.com`).
3. Build command: `npm run build`
4. Output directory: `dist`

Dopo il deploy, apri l'URL del sito Vercel sullo smartphone.

## Configurazione
- `settings.duration`: countdown predefinito (modificabile dall'admin in UI).
- Budget iniziale: 100 (modifica in `client` o `server` se vuoi gestioni avanzate).

## Note
- Questo repository usa WebSocket (Socket.IO). Assicurati che l'hosting supporti connessioni WebSocket.
- Per persistenza dati (squadre, storico), integra un DB (Postgres/Firestore) nel server.
